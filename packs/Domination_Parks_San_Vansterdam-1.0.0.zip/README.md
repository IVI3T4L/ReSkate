# Domination Parks San Vansterdam

Five Domination parks on San Vansterdam, where the game puts its own skate challenges: Rolling Waves, Bonski Park, Hartcore Plaza, FlowTopia and El-One Courts.

## Parks

- **Rolling Waves** (12 spots) on San Vansterdam
- **Bonski Park** (8 spots) on San Vansterdam
- **Hartcore Plaza** (12 spots) on San Vansterdam
- **FlowTopia** (9 spots) on San Vansterdam
- **El-One Courts** (5 spots) on San Vansterdam

## Maps they need

- **San Vansterdam**: comes with the game

## Playing

Needs ReSkate with Domination. Switch this mod on in the launcher's MODS page, then in game:
pause menu > Multiplayer > DOMINATION, pick the map and the park, and Start round.
Everyone in a round needs the same version of this pack.

A park here overrides a built-in park with the same id, so this pack can update one without a new ReSkate.

Version 1.0.0.
