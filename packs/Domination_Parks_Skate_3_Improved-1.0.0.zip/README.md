# Domination Parks Skate 3 Improved

Five Domination parks on the Skate 3 Improved map mod: the red-bowl park, Hillside park, Industrial bowls, Sunken banks and Loans plaza. Needs 333-Skate_3_Improved.

## Parks

- **Red-bowl park** (20 spots) on Skate 3 Improved
- **Hillside park** (9 spots) on Skate 3 Improved
- **Industrial bowls** (7 spots) on Skate 3 Improved
- **Sunken banks** (6 spots) on Skate 3 Improved
- **Loans plaza** (6 spots) on Skate 3 Improved

## Maps they need

- **Skate 3 Improved**: the map mod `333-Skate_3_Improved` (install it from the MODS page too)

## Playing

Needs ReSkate with Domination. Switch this mod on in the launcher's MODS page, then in game:
pause menu > Multiplayer > DOMINATION, pick the map and the park, and Start round.
Everyone in a round needs the same version of this pack.

A park here overrides a built-in park with the same id, so this pack can update one without a new ReSkate.

Version 1.0.0.
